﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MillenniumCalendar.Controllers
{
    public class InicioController : Controller
    {
        // Contexto de datos
        MillenniumCalendarDataContext database = new MillenniumCalendarDataContext();

        // Metodo ActionResult para las Actividades
        public ActionResult Index()
        {
            // Hacemos el select a la vista ya creada
            var ListaActividades = (from c in database.VW_listar_actividades select c).ToList();

            // Enviamos la lista que espera la vista
            return View(ListaActividades);
        }

        // Metodo ActionResult para las categorias 
        public ActionResult categorias()
        {
            // Hacemos el select a la vista ya creada
            var ListaCategorias = (from c in database.VW_listar_categorias select c).ToList();

            // Enviamos la lista que espera la vista
            return View(ListaCategorias);
        }

        // Metodo ActionResult para los facilitadores
        public ActionResult facilitadores()
        {
            // Hacemos el select a la vista ya creada
            var Listafacilitadores = (from c in database.VW_listar_facilitadores select c).ToList();

            // Enviamos la lista que espera la vista
            return View(Listafacilitadores);
        }

    }
}