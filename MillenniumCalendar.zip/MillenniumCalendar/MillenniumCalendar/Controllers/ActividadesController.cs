﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MillenniumCalendar.Controllers
{
    public class ActividadesController : Controller
    {
        // Contexto de datos
        MillenniumCalendarDataContext database = new MillenniumCalendarDataContext();

        // GET: Actividades
        public ActionResult Index()
        {
            var ListarActividades = database.SP_mostrar_actividad().ToList();
            return View(ListarActividades);
        }

        // GET: Actividades/Details/5
        public ActionResult Details(int id)
        {
            var info_actividad = database.SP_buscar_actividad_id(id);
            return View(info_actividad);
        }

        // GET: Actividades/Create
        public ActionResult Create()
        {
            // Listamos las categorias para las activiades
            var ListaCategoria = database.SP_mostrar_categorias().ToList();
            // Creamos el ViewBag para mover la informacion
            ViewBag.categorias = ListaCategoria;

            // Listamos los facilitadores para las activiades
            var ListaFacilitadores = database.SP_mostrar_facilitador().ToList();
            // Creamos el ViewBag para mover la informacion
            ViewBag.facilitadores = ListaFacilitadores;

            return View();
        }

        // POST: Actividades/Create
        [HttpPost]
        public ActionResult Create(FormCollection collection, actividad actividad_datos)
        {
            try
            {
                // TODO: Add insert logic here
                actividad_datos.actividad_inserta = Session["nombre_completo"].ToString();
                actividad_datos.fecha_inserta = DateTime.Now;

                int id_administrador = Convert.ToInt32(Session["id_administrador"].ToString());

                database.SP_ingresar_actividad(actividad_datos.id_categoria, actividad_datos.id_facilitador, actividad_datos.nombre_actividad, actividad_datos.fecha_inicio, actividad_datos.fecha_final, actividad_datos.dias, actividad_datos.horario, actividad_datos.duracion, actividad_datos.descripcion, actividad_datos.estado_actividad, actividad_datos.actividad_inserta, actividad_datos.fecha_inserta);


                database.SubmitChanges();
       
                /// var ultimo_registro = database.actividad.OrderByDescending(x => x.id_actividad).First().id_actividad;
                // database.SP_ingresar_administrador_actividad(id_administrador, actividad_datos.id_actividad, DateTime.Now, actividad_datos.actividad_inserta,  actividad_datos.fecha_inserta);


                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: Actividades/Edit/5
        public ActionResult Edit(int id)
        {
            // Listamos las categorias para las activiades
            var ListaCategoria = database.SP_mostrar_categorias().ToList();
            // Creamos el ViewBag para mover la informacion
            ViewBag.categorias = ListaCategoria;

            // Listamos los facilitadores para las activiades
            var ListaFacilitadores = database.SP_mostrar_facilitador().ToList();
            // Creamos el ViewBag para mover la informacion
            ViewBag.facilitadores = ListaFacilitadores;

            var info_actividad = database.SP_buscar_actividad_id(id).Single();
            return View(info_actividad);
        }

        // POST: Actividades/Edit/5
        [HttpPost]
        public ActionResult Edit(int id, FormCollection collection, actividad actividad_datos)
        {
            try
            {
                // TODO: Add update logic here
                actividad_datos.actividad_actualiza = Session["nombre_completo"].ToString();
                actividad_datos.fecha_actualiza = DateTime.Now;

                database.SP_actualizar_actividad(id, actividad_datos.id_categoria, actividad_datos.id_facilitador, actividad_datos.nombre_actividad, actividad_datos.fecha_inicio, actividad_datos.fecha_final, actividad_datos.dias, actividad_datos.horario, actividad_datos.duracion, actividad_datos.descripcion, actividad_datos.estado_actividad, actividad_datos.actividad_actualiza, actividad_datos.fecha_actualiza);

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: Actividades/Delete/5
        public ActionResult Delete(int id)
        {
            var info_actividad = database.SP_buscar_actividad_id(id).Single();
            return View(info_actividad);
        }

        // POST: Actividades/Delete/5
        [HttpPost]
        public ActionResult Delete(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add delete logic here
                database.SP_eliminar_actividad(id);
                database.SubmitChanges();

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }
    }
}
