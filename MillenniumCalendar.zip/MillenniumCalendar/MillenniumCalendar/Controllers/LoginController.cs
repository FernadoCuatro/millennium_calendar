﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MillenniumCalendar.Controllers
{
    public class LoginController : Controller
    {
        // Contexto de datos
        MillenniumCalendarDataContext database = new MillenniumCalendarDataContext();

        public ActionResult Login()
        {
            return View();
        }

        public ActionResult error()
        {
            return View();
        }

        public ActionResult validar(login campos)
        {
            var usuario = database.SP_validar_usuario(campos.correo, campos.login_inserta, "c@l3nd4R-Ml^!").Single();

            if (usuario.id_administrador > 0)
            {
                // El usuario existe
                Session["login"] = 1;
                Session["id_administrador"] = usuario.id_administrador;
                Session["nombre"] = usuario.nombre;
                Session["nombre_completo"] = usuario.nombre + " " + usuario.apellido;

                return RedirectToAction("Index", "Administracion");
            }
            else
            {
                // El usuario no existe
                return RedirectToAction("Error", "Login");
            }

        }
    }
}