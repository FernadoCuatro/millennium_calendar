CREATE DATABASE millennium_calendar_db
GO
 USE millennium_calendar_db

GO
 -- --------------------------------------
 -- TABLA [1/6] = administrador
 -- --------------------------------------
 CREATE TABLE administrador (
  id_administrador          INT           IDENTITY(1,1) CONSTRAINT Pk_id_administrador PRIMARY KEY NOT NULL,
  nombre                    VARCHAR(30)   NOT NULL,
  apellido                  VARCHAR(30)   NOT NULL,
  estado_administrador      CHAR(2)       NOT NULL,

  -- CAMPOS DE AUDITORIA 
  administrador_inserta     VARCHAR(30)   NOT NULL,
  fecha_inserta             DATETIME      NOT NULL,
  administrador_actualiza   VARCHAR(30)   NULL,
  fecha_actualiza           DATETIME      NULL
 );

GO
 -- --------------------------------------
 -- TABLA [2/6] = administrador_actividad
 -- --------------------------------------
 CREATE TABLE administrador_actividad (
  id_proceso                INT           IDENTITY(1,1) CONSTRAINT Pk_id_proceso PRIMARY KEY NOT NULL,
  id_administrador          INT           NOT NULL,
  id_actividad              INT           NOT NULL,
  fecha_proceso             DATE          NOT NULL,

  -- CAMPOS DE AUDITORIA 
  proceso_inserta           VARCHAR(30)   NOT NULL,
  fecha_inserta             DATETIME      NOT NULL,
  proceso_actualiza         VARCHAR(30)   NULL,
  fecha_actualiza           DATETIME      NULL
 );

GO
 -- --------------------------------------
 -- TABLA [3/6] = actividad
 -- --------------------------------------
 CREATE TABLE actividad (
  id_actividad              INT           IDENTITY(1,1) CONSTRAINT Pk_id_actividad PRIMARY KEY NOT NULL,
  id_categoria              INT           NOT NULL,
  id_facilitador            INT           NOT NULL,
  nombre_actividad          VARCHAR(30)   NOT NULL,
  fecha_inicio              DATE          NOT NULL,
  fecha_final               DATE          NOT NULL,
  dias                      VARCHAR(30)   NOT NULL,
  horario                   VARCHAR(30)   NOT NULL,
  duracion                  VARCHAR(30)   NOT NULL,
  descripcion               VARCHAR(300)  NOT NULL,
  estado_actividad          CHAR(2)       NOT NULL,

  -- CAMPOS DE AUDITORIA 
  actividad_inserta         VARCHAR(30)   NOT NULL,
  fecha_inserta             DATETIME      NOT NULL,
  actividad_actualiza       VARCHAR(30)   NULL,
  fecha_actualiza           DATETIME      NULL
 );

GO
 -- --------------------------------------
 -- TABLA [4/6] = categoria
 -- --------------------------------------
 CREATE TABLE categoria (
  id_categoria              INT           IDENTITY(1,1) CONSTRAINT Pk_id_categoria PRIMARY KEY NOT NULL,
  nombre_categoria          VARCHAR(30)   NOT NULL,
  descripcion               VARCHAR(300)  NOT NULL,
  estado_categoria          CHAR(2)       NOT NULL,

  -- CAMPOS DE AUDITORIA 
  usuario_inserta           VARCHAR(30)   NOT NULL,
  fecha_inserta             DATETIME      NOT NULL,
  usuario_actualiza         VARCHAR(30)   NULL,
  fecha_actualiza           DATETIME      NULL
 );

GO
 -- --------------------------------------
 -- TABLA [5/6] = facilitador
 -- --------------------------------------
 CREATE TABLE facilitador (
  id_facilitador            INT           IDENTITY(1,1) CONSTRAINT Pk_id_facilitador PRIMARY KEY NOT NULL,
  nombre_facilitador        VARCHAR(30)   NOT NULL,
  estudio                   VARCHAR(300)  NOT NULL,
  estado_facilitador        CHAR(2)       NOT NULL,

  -- CAMPOS DE AUDITORIA 
  facilitador_inserta       VARCHAR(30)   NOT NULL,
  fecha_inserta             DATETIME      NOT NULL,
  facilitador_actualiza     VARCHAR(30)   NULL,
  fecha_actualiza           DATETIME      NULL
 );

GO
 -- --------------------------------------
 -- TABLA [6/6] = login
 -- --------------------------------------
 CREATE TABLE login (
  id_login                  INT           IDENTITY(1,1) CONSTRAINT Pk_id_login PRIMARY KEY NOT NULL,
  id_administrador          INT           NOT NULL,
  correo                    VARCHAR(70)   NOT NULL,
  clave                     VARBINARY(100)NOT NULL,
  estado_login              CHAR(2)       NOT NULL,

  -- CAMPOS DE AUDITORIA 
  login_inserta             VARCHAR(30)   NOT NULL,
  fecha_inserta             DATETIME      NOT NULL,
  login_actualiza           VARCHAR(30)   NULL,
  fecha_actualiza           DATETIME      NULL,
 );

GO
 -- --------------------------------------
 -- [RELACION ENTRE TABLAS]
 -- --------------------------------------
ALTER TABLE
 login
ADD
 CONSTRAINT Fk_login_administrador FOREIGN KEY (id_administrador) REFERENCES administrador(id_administrador)

ALTER TABLE
 administrador_actividad
ADD
 CONSTRAINT Fk_administradoractividad FOREIGN KEY (id_administrador) REFERENCES administrador(id_administrador)

ALTER TABLE
 administrador_actividad
ADD
 CONSTRAINT Fk_actividad_administrador FOREIGN KEY (id_actividad) REFERENCES actividad (id_actividad)

ALTER TABLE
 actividad
ADD
 CONSTRAINT Fk_actividad_categoria FOREIGN KEY (id_categoria) REFERENCES categoria (id_categoria)

ALTER TABLE
 actividad
ADD
 CONSTRAINT Fk_actividad_facilitador FOREIGN KEY (id_facilitador) REFERENCES facilitador (id_facilitador)
GO

   -- --------------------------------------
   --
   -- [PROCEDIMIENTOS ALMACENADOS]
   -- 
   -- --------------------------------------

   -- [PA LOGIN]
   CREATE PROCEDURE SP_validar_usuario 
   @usuario VARCHAR(50),
   @clave VARCHAR(50),
   @patron VARCHAR(50) AS BEGIN IF EXISTS (
    SELECT
     l.id_administrador,
     c.nombre,
     c.apellido,
   correo
    FROM
     login l
    inner join administrador c on l.id_administrador = c.id_administrador
    WHERE
     correo = @usuario
     AND CONVERT(VARCHAR(50), DECRYPTBYPASSPHRASE(@patron, clave)) = @clave
   AND estado_login = 'A' AND estado_administrador = 'A'
   )
    SELECT
     l.id_administrador,
   c.nombre,
   c.apellido,
   correo
    FROM
     login l
    inner join administrador c on l.id_administrador = c.id_administrador
    WHERE
     correo = @usuario
     AND CONVERT(VARCHAR(50), DECRYPTBYPASSPHRASE(@patron, clave)) = @clave
   AND estado_login = 'A' AND estado_administrador = 'A'
   ELSE
  SELECT
   -1 id_administrador
  END 
  
  GO

   -- [PA TABLA ADMINISTRADOR]
   -- [TABLA ADMINISTRADOR 1/5] CREATE
   CREATE PROCEDURE SP_ingresar_administrador @nombre VARCHAR(30),
   @apellido VARCHAR(30),
   @estado_administrador CHAR(2),
   @administrador_inserta VARCHAR(30),
   @fecha_inserta DATETIME AS BEGIN BEGIN TRY BEGIN TRAN
  INSERT INTO
   administrador(
    nombre,
    apellido,
    estado_administrador,
    administrador_inserta,
    fecha_inserta
   )
  VALUES
  (
    @nombre,
    @apellido,
    @estado_administrador,
    @administrador_inserta,
    @fecha_inserta
   ) COMMIT
  SELECT
   'EL ADMINISTRADOR FUE AGREGADO CON EXITO' Mensaje
  END TRY BEGIN CATCH IF @@TRANCOUNT > 0 ROLLBACK
  SELECT
   'A OCURRIDO UN ERROR' + ERROR_MESSAGE() Mensaje
  END CATCH
  END 

  GO
   -- [TABLA ADMINISTRADOR 2/5] UPDATE
   CREATE PROCEDURE SP_actualizar_administrador 
   @id_administrador INT,
   @nombre VARCHAR(30),
   @apellido VARCHAR(30),
   @estado_administrador CHAR(2),
   @administrador_actualiza VARCHAR(30),
   @fecha_actualiza DATETIME AS BEGIN BEGIN TRY BEGIN TRAN
  UPDATE
   administrador
  SET
   nombre = @nombre,
   apellido = @apellido,
   estado_administrador = @estado_administrador,
   administrador_actualiza = @administrador_actualiza,
   fecha_actualiza = @fecha_actualiza
  WHERE
   id_administrador = @id_administrador COMMIT
  SELECT
   'EL ADMINISTRADOR FUE ACTUALIZADO CON EXITO' Mensaje
  END TRY BEGIN CATCH IF @@TRANCOUNT > 0 ROLLBACK
  SELECT
   'A OCURRIDO UN ERROR' + ERROR_MESSAGE() Mensaje
  END CATCH
  END
  
  GO
   -- [TABLA ADMINISTRADOR 3/5] READ 
   CREATE PROCEDURE SP_mostrar_administradores AS 
  SELECT
   a.id_administrador,
   nombre,
   apellido,
   l.correo,
   estado_administrador,
   l.estado_login,
   a.administrador_inserta,
   a.fecha_inserta,
   a.administrador_actualiza,
   a.fecha_actualiza
  FROM
   administrador a
   inner join login l on a.id_administrador = l.id_administrador
  GO
   -- [TABLA ADMINISTRADOR 4/5] READ BY ID 
   CREATE PROCEDURE SP_buscar_administrador_id
   @id_administrador INT AS
  SELECT
   a.id_administrador,
   nombre,
   apellido,
   l.correo,
   estado_administrador,
   l.estado_login,
   a.administrador_inserta,
   a.fecha_inserta,
   a.administrador_actualiza,
   a.fecha_actualiza,
   l.login_inserta,
   l.fecha_inserta,
   l.login_actualiza,
   l.fecha_actualiza
  FROM
   administrador a
   inner join login l on a.id_administrador = l.id_administrador
  WHERE
   a.id_administrador = @id_administrador
  GO
   -- [TABLA ADMINISTRADOR 5/5] DELETE 
   CREATE PROCEDURE SP_eliminar_administrador 
   @id_administrador INT AS BEGIN BEGIN TRY BEGIN TRAN
  UPDATE
   administrador
  SET
   estado_administrador = 'I'
  WHERE
   id_administrador = @id_administrador COMMIT
  SELECT
   'EL ADMINISTRADOR SE A ELIMINADO' Mensaje
  END TRY BEGIN CATCH IF @@TRANCOUNT > 0 ROLLBACK
  SELECT
   'A OCURRIDO UN ERROR' + ERROR_MESSAGE() Mensaje
  END CATCH
  END 
  GO

  -- [PA TABLA ADMINISTRADOR_ACTIVIDAD]
  -- [TABLA ADMINISTRADOR_ACTIVIDAD 1/5] CREATE 
  CREATE PROCEDURE SP_ingresar_administrador_actividad 
  @id_administrador INT,
  @id_actividad INT,
  @fecha_proceso DATE,
  @proceso_inserta VARCHAR(30),
  @fecha_inserta DATETIME AS BEGIN BEGIN TRY BEGIN TRAN
  INSERT INTO
   administrador_actividad (
    id_administrador,
    id_actividad,
    fecha_proceso,
    proceso_inserta,
    fecha_inserta
   )
  VALUES
   (
    @id_administrador,
    @id_actividad,
    @fecha_proceso,
    @proceso_inserta,
    GETDATE()
   ) COMMIT
  END TRY BEGIN CATCH IF @@TRANCOUNT > 0 ROLLBACK
  SELECT
   'A OCURRIDO UN ERROR' + ERROR_MESSAGE() Mensaje
  END CATCH
  END
  GO
   -- [TABLA ADMINISTRADOR_ACTIVIDAD 2/5] UPDATE 
   CREATE PROCEDURE SP_actualizar_administrador_actividad 
   @id_proceso INT,
   @id_administrador INT,
   @id_actividad INT,
   @fecha_proceso DATE,
   @proceso_inserta VARCHAR(30),
   @proceso_actualiza VARCHAR(30),
   @fecha_actualiza DATETIME AS BEGIN BEGIN TRY BEGIN TRAN
  UPDATE
   administrador_actividad
  SET
   id_administrador = @id_administrador,
   id_actividad = @id_actividad,
   fecha_proceso = @fecha_proceso,
   proceso_inserta = @proceso_inserta,
   proceso_actualiza = @proceso_actualiza,
   fecha_actualiza = GETDATE()
  WHERE
   id_proceso = @id_proceso COMMIT
  END TRY BEGIN CATCH IF @@TRANCOUNT > 0 ROLLBACK
  SELECT
   'A OCURRIDO UN ERROR' + ERROR_MESSAGE() Mensaje
  END CATCH
  END
  GO
   -- [TABLA ADMINISTRADOR_ACTIVIDAD 3/5] READ 
   CREATE PROCEDURE SP_mostrar_administrador_actividad AS BEGIN BEGIN TRY BEGIN TRAN
  SELECT
   id_proceso,
   id_administrador,
   id_actividad,
   fecha_proceso
  FROM
   administrador_actividad COMMIT
  END TRY BEGIN CATCH IF @@TRANCOUNT > 0 ROLLBACK
  SELECT
   'A OCURRIDO UN ERROR' + ERROR_MESSAGE() Mensaje
  END CATCH
  END
  GO
   -- [TABLA ADMINISTRADOR_ACTIVIDAD 4/5] READ BY ID
   CREATE PROCEDURE SP_buscar_administrador_actividad @id_proceso INT AS BEGIN BEGIN TRY BEGIN TRAN
  SELECT
   *
  FROM
   administrador_actividad
  WHERE
   id_proceso = @id_proceso COMMIT
  END TRY BEGIN CATCH IF @@TRANCOUNT > 0 ROLLBACK
  SELECT
   'A OCURRIDO UN ERROR' + ERROR_MESSAGE() Mensaje
  END CATCH
  END
  GO
   -- [TABLA ADMINISTRADOR_ACTIVIDAD 5/5] DELETE
   -- GO

   -- [PA TABLA ACTIVIDAD]
   -- [TABLA ACTIVIDAD 1/5] CREATE 
   CREATE PROCEDURE SP_ingresar_actividad
   @id_categoria INT,
   @id_facilitador INT,
   @nombre_actividad VARCHAR(30),
   @fecha_inicio DATE,
   @fecha_final DATE,
   @dias VARCHAR(30),
   @horario VARCHAR(30),
   @duracion VARCHAR(30),
   @descripcion VARCHAR(300),
   @estado_actividad CHAR(2),
   @actividad_inserta VARCHAR(30),
   @fecha_inserta DATETIME AS BEGIN BEGIN TRY BEGIN TRAN
  INSERT INTO
   actividad (
    id_categoria,
    id_facilitador,
    nombre_actividad,
    fecha_inicio,
    fecha_final,
    dias,
    horario,
    duracion,
    descripcion,
    estado_actividad,
    actividad_inserta,
    fecha_inserta
   )
  VALUES
   (
    @id_categoria,
    @id_facilitador,
    @nombre_actividad,
    @fecha_inicio,
    @fecha_final,
    @dias,
    @horario,
    @duracion,
    @descripcion,
    @estado_actividad,
    @actividad_inserta,
    @fecha_inserta
   ) COMMIT
  SELECT
   'LA ACTIVIDAD SE AGREGO CORRECTAMENTE' Mensaje
  END TRY BEGIN CATCH IF @@TRANCOUNT > 0 ROLLBACK
  SELECT
   'A OCURRIDO UN ERROR' + ERROR_MESSAGE() Mensaje
  END CATCH
  END
  GO
   -- [TABLA ACTIVIDAD 2/5] UPDATE 
   CREATE PROCEDURE SP_actualizar_actividad 
   @id_actividad INT,
   @id_categoria INT,
   @id_facilitador INT,
   @nombre_actividad VARCHAR(30),
   @fecha_inicio DATE,
   @fecha_final DATE,
   @dias VARCHAR(30),
   @horario VARCHAR(30),
   @duracion VARCHAR(30),
   @descripcion VARCHAR(300),
   @estado_actividad CHAR(2),
   @actividad_actualiza VARCHAR(30),
   @fecha_actualiza DATETIME AS BEGIN BEGIN TRY BEGIN TRAN
  UPDATE
   actividad
  SET
   id_categoria = @id_categoria,
   id_facilitador = @id_facilitador,
   nombre_actividad = @nombre_actividad,
   fecha_inicio = @fecha_inicio,
   fecha_final = @fecha_final,
   dias = @dias,
   horario = @horario,
   duracion = @duracion,
   descripcion = @descripcion,
   estado_actividad = @estado_actividad,
   actividad_actualiza = @actividad_actualiza,
   fecha_actualiza = @fecha_actualiza
  WHERE
   id_actividad = @id_actividad COMMIT
  SELECT
   'LA ACTIVIDAD FUE ACTUALIZADA CON EXITO' Mensaje
  END TRY BEGIN CATCH IF @@TRANCOUNT > 0 ROLLBACK
  SELECT
   'A OCURRIDO UN ERROR' + ERROR_MESSAGE() Mensaje
  END CATCH
  END
  GO
   -- [TABLA ACTIVIDAD 3/5] READ 
   CREATE PROCEDURE SP_mostrar_actividad AS
   SELECT
    id_actividad,
    nombre_categoria,
    nombre_facilitador,
    nombre_actividad,
    fecha_inicio,
    fecha_final,
    dias,
    horario,
    duracion,
    a.descripcion,
    estado_actividad,
    actividad_inserta,
    a.fecha_inserta,
    actividad_actualiza,
    a.fecha_actualiza
   FROM
   actividad a
   inner join categoria c on a.id_categoria = c.id_categoria
   inner join facilitador f on a.id_facilitador = f.id_facilitador
  GO
   -- [TABLA ACTIVIDAD 4/5] READ BY ID
   CREATE PROCEDURE SP_buscar_actividad_id 
   @id_actividad INT AS BEGIN BEGIN TRY BEGIN TRAN
  SELECT
    id_actividad,
    a.id_categoria,
    nombre_categoria,
    a.id_facilitador,
    nombre_facilitador,
    nombre_actividad,
    fecha_inicio,
    fecha_final,
    dias,
    horario,
    duracion,
    a.descripcion,
    estado_actividad,
    actividad_inserta,
    a.fecha_inserta,
    actividad_actualiza,
    a.fecha_actualiza
  FROM
   actividad a
   inner join categoria c on a.id_categoria = c.id_categoria
   inner join facilitador f on a.id_facilitador = f.id_facilitador
  WHERE
   id_actividad = @id_actividad COMMIT
  SELECT
   'LA ACTIVIDAD SE ENCONTRO' Mensaje
  END TRY BEGIN CATCH IF @@TRANCOUNT > 0 ROLLBACK
  SELECT
   'A OCURRIDO UN ERROR' + ERROR_MESSAGE() Mensaje
  END CATCH
  END
  GO
   -- [TABLA ACTIVIDAD 5/5] DELETE
   CREATE PROCEDURE SP_eliminar_actividad @id_actividad INT AS BEGIN BEGIN TRY BEGIN TRAN
  UPDATE
   actividad
  SET
   estado_actividad = 'I'
  WHERE
   id_actividad = @id_actividad COMMIT
  SELECT
   'LOS DATOS HAN SIDO ELIMINADOS' Mensaje
  END TRY BEGIN CATCH IF @@TRANCOUNT > 0 ROLLBACK
  SELECT
   'A OCURRIDO UN ERROR' + ERROR_MESSAGE() Mensaje
  END CATCH
  END 
  GO

  -- [PA TABLA CATEGORIA]
  -- [TABLA CATEGORIA 1/5] CREATE 
  CREATE PROCEDURE SP_agregar_categoria
  @nombre_categoria VARCHAR(30),
  @descripcion VARCHAR(300),
  @estado_categoria CHAR(2),
  @usuario_inserta VARCHAR(30),
  @fecha_inserta DATETIME AS BEGIN BEGIN TRY BEGIN TRAN
  INSERT INTO
   categoria (
    nombre_categoria,
    descripcion,
    estado_categoria,
    usuario_inserta,
    fecha_inserta
   )
  VALUES
  (
    @nombre_categoria,
    @descripcion,
    @estado_categoria,
    @usuario_inserta,
    @fecha_inserta
   ) COMMIT
  SELECT
   'LA CATEGORIA FUE AGREGADA CON EXITO' Mensaje
  END TRY BEGIN CATCH IF @@TRANCOUNT > 0 ROLLBACK
  SELECT
   'HA OCURRIDO UN ERROR' + ERROR_MESSAGE() Mensaje
  END CATCH
  END
  GO
   -- [TABLA CATEGORIA 2/5] UPDATE 
   CREATE PROCEDURE SP_actualiza_categoria 
   @id_categoria INT,
   @nombre_categoria VARCHAR(30),
   @descripcion VARCHAR(300),
   @estado_categoria CHAR(2),
   @usuario_actualiza VARCHAR(30),
   @fecha_actualiza DATETIME AS BEGIN BEGIN TRY BEGIN TRAN
  UPDATE
   categoria
  SET
   nombre_categoria = @nombre_categoria,
   descripcion = @descripcion,
   estado_categoria = @estado_categoria,
   usuario_actualiza = @usuario_actualiza,
   fecha_actualiza = @fecha_actualiza
  WHERE
   id_categoria = @id_categoria COMMIT
  SELECT
   'LA CATEGORIA FUE ACTUALIZADA CON EXITO' Mensaje
  END TRY BEGIN CATCH IF @@TRANCOUNT > 0 ROLLBACK
  SELECT
   'HA OCURRIDO UN ERROR' + ERROR_MESSAGE() Mensaje
  END CATCH
  END
  GO
   -- [TABLA CATEGORIA 3/5] READ 
   CREATE PROCEDURE SP_mostrar_categorias AS 
  SELECT
   *
  FROM
   categoria
  GO
   -- [TABLA CATEGORIA 4/5] READ BY ID
   CREATE PROCEDURE SP_buscar_categoria_id 
   @id_categoria INT AS
  SELECT
  *
  FROM
   categoria
  WHERE
   id_categoria = @id_categoria
  GO
   -- [TABLA CATEGORIA 5/5] DELETE
   CREATE PROCEDURE SP_eliminar_categoria @id_categoria INT AS BEGIN BEGIN TRY BEGIN TRAN
  UPDATE
   categoria
  SET
   estado_categoria = 'I'
  WHERE
   id_categoria = @id_categoria COMMIT
  SELECT
   'LA CATEGORIA SE INHABILITO' Mensaje
  END TRY BEGIN CATCH IF @@TRANCOUNT > 0 ROLLBACK
  SELECT
   'HA OCURRIDO UN ERROR' + ERROR_MESSAGE() Mensaje
  END CATCH
  END
  GO

   -- [PA TABLA FACILITADOR]
   -- [TABLA FACILITADOR 1/5] CREATE
   CREATE PROCEDURE SP_agregar_facilitador 
   @nombre_facilitador VARCHAR(30),
   @estudio VARCHAR(100),
   @estado_facilitador CHAR(2),
   @facilitador_inserta VARCHAR(30),
   @fecha_inserta DATETIME AS BEGIN BEGIN TRY BEGIN TRAN
  INSERT INTO
   facilitador (
   nombre_facilitador,
   estudio,
   estado_facilitador,
   facilitador_inserta,
   fecha_inserta
   )
  VALUES
  (
    @nombre_facilitador,
    @estudio,
    @estado_facilitador,
    @facilitador_inserta,
    @fecha_inserta
   ) COMMIT
  SELECT
   'EL FACILITADOR FUE AGREGADO CON EXITO' Mensaje
  END TRY BEGIN CATCH IF @@TRANCOUNT > 0 ROLLBACK
  SELECT
   'HA OCURRIDO UN ERROR' + ERROR_MESSAGE() Mensaje
  END CATCH
  END
  GO
   -- [TABLA FACILITADOR 2/5] UPDATE
   CREATE PROCEDURE SP_actualiza_facilitador 
   @id_facilitador INT,
   @nombre_facilitador VARCHAR(30),
   @estudio VARCHAR(300),
   @estado_facilitador CHAR(2),
   @facilitador_actualiza VARCHAR(30),
   @fecha_actualiza DATETIME AS BEGIN BEGIN TRY BEGIN TRAN
  UPDATE
   facilitador
  SET
   nombre_facilitador = @nombre_facilitador,
   estudio = @estudio,
   estado_facilitador = @estado_facilitador,
   facilitador_actualiza = @facilitador_actualiza,
   fecha_actualiza = @fecha_actualiza
  WHERE
   id_facilitador = @id_facilitador COMMIT
  SELECT
   'EL FACILITADOR FUE ACTUALIZADO CON EXITO' Mensaje
  END TRY BEGIN CATCH IF @@TRANCOUNT > 0 ROLLBACK
  SELECT
   'HA OCURRIDO UN ERROR' + ERROR_MESSAGE() Mensaje
  END CATCH
  END
  GO
   -- [TABLA FACILITADOR 3/5] READ
   CREATE PROCEDURE SP_mostrar_facilitador AS 
  SELECT
   *
  FROM
   facilitador
  GO
   -- [TABLA FACILITADOR 4/5] READ BY ID
   CREATE PROCEDURE SP_buscar_facilitador_id 
   @id_facilitador char AS
  SELECT
   *
  FROM
   facilitador
  WHERE
   id_facilitador = @id_facilitador
  GO
   -- [TABLA FACILITADOR 5/5] DELETE
   CREATE PROCEDURE SP_eliminar_facilitador @id_facilitador INT AS BEGIN BEGIN TRY BEGIN TRAN
  UPDATE
   facilitador
  SET
   estado_facilitador = 'I'
  WHERE
   id_facilitador = @id_facilitador COMMIT
  SELECT
   'EL FACILITADOR SE ELIMINO' Mensaje
  END TRY BEGIN CATCH IF @@TRANCOUNT > 0 ROLLBACK
  SELECT
   'HA OCURRIDO UN ERROR' + ERROR_MESSAGE() Mensaje
  END CATCH
  END

  GO
   -- [PA TABLA LOGIN]
   -- [TABLA LOGIN 1/5] CREATE
   CREATE PROCEDURE SP_agregar_login
   @id_administrador INT,
   @correo VARCHAR(70),
   @clave VARCHAR(100),
   @patron VARCHAR(100),
   @estado_login CHAR(2),
   @login_inserta VARCHAR(30),
   @fecha_inserta DATETIME AS BEGIN BEGIN TRY BEGIN TRAN
  INSERT INTO
   login (
   id_administrador,
   correo,
   clave,
   estado_login,
   login_inserta,
   fecha_inserta
   )
  VALUES
  (
    @id_administrador,
    @correo,
    ENCRYPTBYPASSPHRASE(@patron, @clave),
    @estado_login,
    @login_inserta,
    @fecha_inserta
   ) COMMIT
  SELECT
   'EL LOGIN FUE AGREGADO CON EXITO' Mensaje
  END TRY BEGIN CATCH IF @@TRANCOUNT > 0 ROLLBACK
  SELECT
   'HA OCURRIDO UN ERROR' + ERROR_MESSAGE() Mensaje
  END CATCH
  END
   -- [TABLA LOGIN 2/5] UPDATE
   CREATE PROCEDURE SP_actualiza_login
   @id_administrador INT,
   @correo VARCHAR(70),
   @estado_login CHAR(2),
   @login_actualiza VARCHAR(30),
   @fecha_actualiza DATETIME AS BEGIN BEGIN TRY BEGIN TRAN
  UPDATE
   login
  SET
   correo = @correo,
   estado_login = @estado_login,
   login_actualiza = @login_actualiza,
   fecha_actualiza = @fecha_actualiza
  WHERE
   id_administrador = @id_administrador COMMIT
  SELECT
   'EL LOGIN FUE ACTUALIZADO CON EXITO' Mensaje
  END TRY BEGIN CATCH IF @@TRANCOUNT > 0 ROLLBACK
  SELECT
   'HA OCURRIDO UN ERROR' + ERROR_MESSAGE() Mensaje
  END CATCH
  END

   -- [TABLA LOGIN 5/5] DELETE 
   CREATE PROCEDURE SP_eliminar_login
   @id_login INT AS BEGIN BEGIN TRY BEGIN TRAN
  UPDATE
   login
  SET
   estado_login = 'I'
  WHERE
   id_login = @id_login COMMIT
  SELECT
   'EL LOGIN SE A ELIMINADO' Mensaje
  END TRY BEGIN CATCH IF @@TRANCOUNT > 0 ROLLBACK
  SELECT
   'A OCURRIDO UN ERROR' + ERROR_MESSAGE() Mensaje
  END CATCH
  END 
  GO


  -- --------------------------------------
  --
  -- [VISTAS]
  -- 
  -- --------------------------------------
  GO
  -- Vista para administradores
  CREATE VIEW VW_listar_administradores AS
    SELECT nombre,apellido,estado_administrador,administrador_inserta,fecha_inserta,administrador_actualiza,fecha_actualiza 
  FROM administrador

  GO
  -- VISTA DE ACTIVIDADES
   CREATE VIEW VW_listar_actividades AS
  SELECT
    nombre_categoria,
    nombre_facilitador,
    nombre_actividad,
    fecha_inicio,
    fecha_final,
    dias,
    horario,
    duracion,
    a.descripcion
  FROM
   actividad a
   inner join categoria c on a.id_categoria = c.id_categoria
   inner join facilitador f on a.id_facilitador = f.id_facilitador
  WHERE
   estado_actividad = 'A'
  GO
  -- VISTA DE CATEGORIAS
   CREATE VIEW VW_listar_categorias AS
  SELECT
   nombre_categoria,
   descripcion
  FROM
   categoria
  WHERE
   estado_categoria = 'A'
  GO
  -- VISTA DE FACILITADORES
   CREATE VIEW VW_listar_facilitadores AS
  SELECT
   nombre_facilitador,
   estudio
  FROM
   facilitador
  WHERE
   estado_facilitador = 'A'
  GO

--------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------
-- TOTAL TABLAS: 6
-- TOTAL DE PROCEDIMIENTOS ALMACENADOS: 
-- TOTAL DE VISTAS: 
--------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------