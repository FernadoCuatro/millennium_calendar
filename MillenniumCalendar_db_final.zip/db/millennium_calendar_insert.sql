-- --------------------------------------
--
-- [DML DE CADA TABLA]
-- 
-- --------------------------------------

-- Se recomienda ingresar los DML tabla por tabla

-- [TABLA CATEGORIA]
USE millennium_calendar_db;
GO
EXECUTE SP_agregar_categoria 'finanzas', 'economía y probabilidades', 'A', 'Fernando Cuatro', '2021-01-01'
EXECUTE SP_agregar_categoria 'matemáticas', 'lógica matemática y desarrollo de planteamientos', 'A', 'Fernando Cuatro', '2021-01-01'
EXECUTE SP_agregar_categoria 'programación', 'estudio de tecnologías innovadoras e impresionantes', 'A', 'Fernando Cuatro', '2021-01-01'

EXECUTE SP_actualiza_categoria '1','Finanzas', 'Economía y probabilidades', 'A', 'Fernando Quinto', '2021-02-02'
EXECUTE SP_actualiza_categoria '2','Matemáticas', 'Lógica matemática y desarrollo de planteamientos', 'A', 'Fernando Quinto', '2021-02-02'
EXECUTE SP_actualiza_categoria '3','Programación', 'Estudio de tecnologías innovadoras e impresionantes', 'A', 'Fernando Quinto', '2021-02-02'

-- EXECUTE SP_buscar_categoria_ID 1
-- EXECUTE SP_eliminar_categoria 1
-- EXECUTE SP_mostrar_categorias
-- SELECT * from VW_listar_categorias

-- [TABLA FACILITADOR]
USE millennium_calendar_db;
GO
EXECUTE SP_agregar_facilitador 'Melissa Alexandra Lopez', 'Licenciada en administración de empresas', 'A', 'Fernando Cuatro', '2021-03-03';
EXECUTE SP_agregar_facilitador 'Cony Abigail Hernandez', 'Maestría en informática y diseño web', 'A', 'Fernando Cuatro', '2021-03-03';
EXECUTE SP_agregar_facilitador 'Juan Pablo Chinchilla', 'Ingeniero en programación y ciencia de datos', 'A', 'Fernando Cuatro', '2021-03-03';

EXECUTE SP_actualiza_facilitador '1', 'Melissa Alexandra Lopez', 'Licenciada en administración de empresas', 'A', 'Fernando Sexto', '2021-04-04';
EXECUTE SP_actualiza_facilitador '2','Cony Abigail Hernandez Rebelo', 'Maestría en informática y diseño web', 'I', 'Fernando Sexto', '2021-04-04';
EXECUTE SP_actualiza_facilitador '3','Juan Pablo Chinchilla Clarkson', 'Ingeniero en programación y ciencia de datos', 'A', 'Fernando Sexto', '2021-04-04';

-- EXECUTE SP_buscar_facilitador_id 1
-- EXECUTE SP_eliminar_facilitador 2
-- EXECUTE SP_mostrar_facilitador
-- SELECT * from VW_listar_facilitadores

-- [TABLA ACTIVIDAD]
USE millennium_calendar_db;
GO
EXECUTE SP_ingresar_actividad 2, 1, 'Curso de desarrollo en ASP.NET', '2021-11-03', '2021-11-29', 'Lunes y Viernes', '11:00 - 15:00', '60 horas','Desarrollo completo y practico con ASP.NET con MVC y LinQ', 'A',  'Fernando Cuatro', '2021-05-05'
EXECUTE SP_ingresar_actividad 3, 3, 'Álgebra lineal', '2021-12-05', '2021-12-20', 'Martes, Jueves y Viernes', '07:00 - 12:00', '35 horas','Fundamentos en desarrollo algebraico de básico a avanzado', 'A',  'Fernando Cuatro', '2021-05-05'

EXECUTE SP_actualizar_actividad 1, 3, 3, 'Álgebra lineal', '2021-12-05', '2021-12-20', 'Martes, Jueves y Viernes', '07:00 - 12:00', '35 horas','Fundamentos en desarrollo algebraico de básico a avanzado', 'A',  'Fernando Séptimo', '2021-06-06'  
EXECUTE SP_actualizar_actividad 2, 2, 1, 'Curso de desarrollo en ASP.NET', '2021-11-03', '2021-11-29', 'Lunes y Viernes', '11:00 - 15:00', '60 horas','Desarrollo completo y practico con ASP.NET con MVC y LinQ', 'A',  'Fernando Séptimo', '2021-06-06'

-- EXECUTE SP_buscar_actividad_id 1
-- EXECUTE SP_eliminar_actividad 1
-- EXECUTE SP_mostrar_actividad
-- SELECT * from VW_listar_actividades

-- [TABLA ADMINISTRADOR Y LOGIN]
USE millennium_calendar_db;
GO
EXECUTE SP_ingresar_administrador 'Carlos','Castellanos','A','Carlos Castellanos','2021-07-07' 
EXECUTE SP_ingresar_administrador 'Daniela','Avendaño','A','Fernando Cuatro','2021-07-07' 
-- Al mismo tiempo que se agrega el administrador, se agrega su acceso al login
EXECUTE SP_agregar_login 1, 'carlos@correo.com', 'holamundo', 'c@l3nd4R-Ml^!', 'A', 'Fernando Cuatro', '2021-07-07'
EXECUTE SP_agregar_login 2, 'daniela@correo.com', 'hola123', 'c@l3nd4R-Ml^!', 'A', 'Carlos Castellanos', '2021-07-07'

EXECUTE SP_actualizar_administrador 2, 'Daniela', 'Avendaño', 'A', 'Carlos Castellanos', '2021-08-08'
EXECUTE SP_actualiza_login 2, 'daniela@correo.com', 'A', 'Carlos Castellanos', '2021-08-08'

-- EXECUTE SP_buscar_administrador_id 2
-- EXECUTE SP_eliminar_administrador 1
-- EXECUTE SP_eliminar_login 2
-- EXECUTE SP_mostrar_administradores

-- INICIO DE SESION
-- EXECUTE SP_validar_usuario 'correo@correo.com', 'holamundo', 'c@l3nd4R-Ml^!';
