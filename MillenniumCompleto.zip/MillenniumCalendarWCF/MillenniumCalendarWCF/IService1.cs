﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;

namespace MillenniumCalendarWCF
{
    [ServiceContract]
    public interface IService1
    {
        [OperationContract]
        List<VW_listar_actividades> VW_listar_actividades();

        [OperationContract]
        List<VW_listar_categorias> VW_listar_categorias();

        [OperationContract]
        List<VW_listar_facilitadores> VW_listar_facilitadores();
    }
}
