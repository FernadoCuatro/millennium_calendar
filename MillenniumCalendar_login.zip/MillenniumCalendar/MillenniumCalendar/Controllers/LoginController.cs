﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MillenniumCalendar.Controllers
{
    public class LoginController : Controller
    {
        // Contexto de datos
        MillenniumCalendarDataContext database = new MillenniumCalendarDataContext();

        public ActionResult Login()
        {
            return View();
        }

        public ActionResult error()
        {
            return View();
        }

        public ActionResult validar(login campos)
        {
            int numero = 1;

            if (numero > 0)
            {
                return RedirectToAction("Index", "Administracion");
            }
            else
            {
                return RedirectToAction("Error", "Login");
            }

        }
    }
}